# Chappie-II

基于ESP32的简易掌上终端~

视频介绍：https://www.bilibili.com/video/BV1QL411S7jo

硬件开源链接：https://oshwhub.com/eedadada/chappie2

![](https://github.com/Forairaaaaa/Chappie-II/blob/main/Pics/Chappie-II_Cover_43.png?raw=true)

![](https://github.com/Forairaaaaa/Chappie-II/blob/main/Pics/captrue1.png?raw=true)

![](https://github.com/Forairaaaaa/Chappie-II/blob/main/Pics/captrue2.png?raw=true)

![](https://github.com/Forairaaaaa/Chappie-II/blob/main/Pics/captrue3.png?raw=true)

![](https://github.com/Forairaaaaa/Chappie-II/blob/main/Pics/captrue4.png?raw=true)