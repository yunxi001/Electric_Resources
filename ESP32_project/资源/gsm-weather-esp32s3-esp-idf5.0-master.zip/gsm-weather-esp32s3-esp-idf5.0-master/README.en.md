# gsm-weather-esp32s3-esp-idf5.0

#### Description

GSM_Wheather_S3 ESP32S3代码仓库，使用ESP32官方esp-idf-v5.0开发，需要安装相关开发环境。
<br>
视频演示地址：https://www.bilibili.com/video/BV1VU4y1v7VD?vd_source=2847f5d974d73d579ce40eb1213b09ff
<br>
字库UI设计开源地址:https://gitee.com/gsm-wheather-project/gsm-weather-s3-comprehensive-information
<br>
硬件开源地址：https://oshwhub.com/yeshengchengxuyuan/b4b67ab1e8234aeebea054b4eda6f549

食用过程中有疑问可以通过下面联系方式与我联系:
<br>
开源地址：https://gitee.com/gsm-wheather-project
<br>
微信:GM8988
<br>
QQ:1063503277
<br>
QQ交流群:709259833

#### image
![image](doc/image/001.jpg)
![image](doc/image/002.jpg)
![image](doc/image/003.jpg)
![image](doc/image/004.jpg)
![image](doc/image/005.jpg)
![image](doc/image/006.jpg)
<br>
更多外观图片：https://gitee.com/gsm-wheather-project/gsm-weather-s3-comprehensive-information/tree/master/%E5%A4%96%E8%A7%82

#### Software Architecture
Software architecture description

#### Installation

1.  xxxx
2.  xxxx
3.  xxxx

#### Instructions

1.  xxxx
2.  xxxx
3.  xxxx

#### Contribution

1.  Fork the repository
2.  Create Feat_xxx branch
3.  Commit your code
4.  Create Pull Request


#### Gitee Feature

1.  You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2.  Gitee blog [blog.gitee.com](https://blog.gitee.com)
3.  Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4.  The most valuable open source project [GVP](https://gitee.com/gvp)
5.  The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6.  The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
