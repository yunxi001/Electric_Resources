#ifndef __DELAY_H
#define __DELAY_H
#include "main.h"
#include <freertos/FreeRTOS.h>


void delay_us(int us);
void delay_ms(int ms);

#endif
















