#include "bmp_ShuaXin.h"
#include "lvgl/lvgl.h"

const lv_img_dsc_t *bmp_ShuaXin_buf[16] =
{
&bmp_ShuaXin_0,
&bmp_ShuaXin_1,
&bmp_ShuaXin_2,
&bmp_ShuaXin_3,
&bmp_ShuaXin_4,
&bmp_ShuaXin_5,
&bmp_ShuaXin_6,
&bmp_ShuaXin_7,
&bmp_ShuaXin_8,
&bmp_ShuaXin_9,
&bmp_ShuaXin_10,
&bmp_ShuaXin_11,
&bmp_ShuaXin_12,
&bmp_ShuaXin_13,
&bmp_ShuaXin_14,
&bmp_ShuaXin_15,
};

