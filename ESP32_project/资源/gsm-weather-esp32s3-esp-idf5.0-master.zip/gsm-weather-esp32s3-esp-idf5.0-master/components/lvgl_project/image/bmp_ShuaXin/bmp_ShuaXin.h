#ifndef __bmp_ShuaXin_h__
#define __bmp_ShuaXin_h__
#include "lvgl/lvgl.h"


LV_IMG_DECLARE(bmp_ShuaXin_0)
LV_IMG_DECLARE(bmp_ShuaXin_1)
LV_IMG_DECLARE(bmp_ShuaXin_2)
LV_IMG_DECLARE(bmp_ShuaXin_3)
LV_IMG_DECLARE(bmp_ShuaXin_4)
LV_IMG_DECLARE(bmp_ShuaXin_5)
LV_IMG_DECLARE(bmp_ShuaXin_6)
LV_IMG_DECLARE(bmp_ShuaXin_7)
LV_IMG_DECLARE(bmp_ShuaXin_8)
LV_IMG_DECLARE(bmp_ShuaXin_9)
LV_IMG_DECLARE(bmp_ShuaXin_10)
LV_IMG_DECLARE(bmp_ShuaXin_11)
LV_IMG_DECLARE(bmp_ShuaXin_12)
LV_IMG_DECLARE(bmp_ShuaXin_13)
LV_IMG_DECLARE(bmp_ShuaXin_14)
LV_IMG_DECLARE(bmp_ShuaXin_15)

extern const lv_img_dsc_t *bmp_ShuaXin_buf[16];

#endif

