#ifndef __bmp_tianqi_80x80_h__
#define __bmp_tianqi_80x80_h__
#include "lvgl.h"

LV_IMG_DECLARE(bmp_BeiJing)
#endif

