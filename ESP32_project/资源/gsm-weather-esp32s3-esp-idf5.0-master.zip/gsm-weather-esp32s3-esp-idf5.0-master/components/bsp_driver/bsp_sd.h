#ifndef __bsp_sd_h__
#define __bsp_sd_h__

#include "stdint.h"
#include "stdio.h"

uint8_t bsp_sd_init(void);

#endif
